<html>
	<head><title>Laman Web STTS</title>
	<link rel="stylesheet" type = "text/css" href="style.css">
	</head>
		<body>
            
          
<div id="container">

        <div id="banner" align="center">
        <img src="img/logo3.png" width="208" height="242"  align="bottom">
        </div>
        
        <div id = "header">

                <h1>SEKOLAH TEKNOLOGI TINGGI SEKALI</h1>
        </div>

        <div id="content">
            
          <div id="nav">
                    <ul>
                    <li align="center"><h3>MENU NAVIGASI</h3></li>
                    <li align="center"><h3>______________</h3></li>
                    <li><a href="homepage.php">UTAMA</a></li>
                    <li><a href="#">PENGUMUMAN</a></li>
                    <li><a href="#">LOG MASUK</a></li>

                    </ul>
                    </div>
            
                    <div id="main">
                        <p>Pilih sistem-sistem di bawah untuk meneruskan:</p>
                        <br>
                        <a href="aduan.php" target="_blank"><img src="img/banner4.jpg" height="20%" width="90%"></a><br><br>
                        <hr width="90%" align="left"><br>
                        <a href="pertandingan.php" target="_blank"><img src="img/banner5.jpg" height="20%" width="90%"></a>
               

                    </div>
        </div>

                <div id="footer">Copyright &copy; 2019
                </div>

            </div>

                </body>
        </html>